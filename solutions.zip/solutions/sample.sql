create database pizzahut;
use pizzahut;
 select * from pizzas;  
 create table orders( order_id int not null primary key, order_date date not null, order_time time not null);
 create table orders_details( order_details_id int not null primary key, order_id int not null, pizza_id text not null, quantity int not null);
 select count(*) from orders_details;
 drop table order_details;