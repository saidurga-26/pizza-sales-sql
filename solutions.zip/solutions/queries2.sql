-- Q6. Join the necessary tables to find the total quantity of each pizza category ordered.

select pizza_types.category, sum(orders_details.quantity) as total_quantity
from pizza_types join pizzas
on pizza_types.pizza_type_id=pizzas.pizza_type_id
join orders_details
on orders_details.pizza_id=pizzas.pizza_id
group by pizza_types.category order by total_quantity;

-- Q7. Determine the distribution of orders by hour of the day.

select hour(order_time), count(order_id) as total_orders
from orders
group by hour(order_time);

-- Q8. Join relevant tables to find the category-wise distribution of pizzas.

select category, count(name) as distributed
from pizza_types
group by category;

-- Q9. Group the orders by date and calculate the average number of pizzas ordered per day.

select round(avg(orders_perday),0)
from
(select orders.order_date, count(orders_details.quantity) as orders_perday
from orders join orders_details
on orders.order_id=orders_details.order_id
group by orders.order_date) as avg_orders_perday;

-- Q10. Determine the top 3 most ordered pizza types based on revenue.

select pizza_types.pizza_type_id, sum((orders_details.quantity*pizzas.price)) as revenue
from pizza_types join pizzas
on pizza_types.pizza_type_id=pizzas.pizza_type_id
join orders_details
on orders_details.pizza_id=pizzas.pizza_id
group by pizza_types.pizza_type_id 
order by revenue desc limit 3;