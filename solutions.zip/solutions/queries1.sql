-- Q1. Retrieve the total number of orders placed.

select count(*) as total_orders from orders;

-- Q2. Calculate the total revenue generated from pizza sales.

select 
round(sum((orders_details.quantity*pizzas.price)),2) as total_revenue
from orders_details join pizzas
on orders_details.pizza_id=pizzas.pizza_id;

-- Q3. Identify the highest-priced pizza.

select pizza_types.name, pizzas.price
from pizza_types join pizzas
on pizza_types.pizza_type_id=pizzas.pizza_type_id
order by pizzas.price desc
limit 1;

-- Q4. Identify the most common pizza size ordered.

select quantity, count(quantity) as total_orders
from orders_details
group by quantity;

-- Q5. List the top 5 most ordered pizza types along with their quantities.

select pizza_types.name, sum(orders_details.quantity) as total_quantity
from pizza_types join pizzas
on pizza_types.pizza_type_id=pizzas.pizza_type_id 
join orders_details 
on orders_details.pizza_id=pizzas.pizza_id
group by pizza_types.name
order by total_quantity desc limit 5;

